﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для CarsAddWindow.xaml
    /// </summary>
    public partial class CarsAddWindow : Window
    {
        public CarsAddWindow()
        {
            InitializeComponent();
            try
            {
                ManufacturerNameComboBox.ItemsSource = GIBDDEntities.GetContext().Manufacture.ToList();
                ModelComboBox.ItemsSource = GIBDDEntities.GetContext().Model.ToList();
                CarColorComboBox.ItemsSource = GIBDDEntities.GetContext().CarColors.ToList();
                EngineTypeComboBox.ItemsSource = GIBDDEntities.GetContext().EngineTypes.ToList();
                TypeOfDriveComboBox.ItemsSource = GIBDDEntities.GetContext().TypeOfDrive.ToList();
                DriverComboBox.ItemsSource = GIBDDEntities.GetContext().Drivers.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }



        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(VinTextBox.Text))
                errors.AppendLine("VIN не может быть пустым");
            else if (VinTextBox.Text.Length != 17)
                errors.AppendLine("VIN должен содержать 17 символов");

            if (ManufacturerNameComboBox.SelectedItem == null)
                errors.AppendLine("Выберите производителя");

            if (ModelComboBox.SelectedItem == null)
                errors.AppendLine("Выберите модель");

            if (string.IsNullOrWhiteSpace(YearTextBox.Text))
                errors.AppendLine("Введите год выпуска");
            else if (!int.TryParse(YearTextBox.Text, out int year) || year < 1886 || year > DateTime.Now.Year + 1)
                errors.AppendLine($"Год должен быть в диапазоне 1886 - {DateTime.Now.Year + 1}");

            if (string.IsNullOrWhiteSpace(WeightTextBox.Text))
                errors.AppendLine("Введите вес");
            else if (!int.TryParse(WeightTextBox.Text, out int weight) || weight <= 0)
                errors.AppendLine("Вес должен быть больше 0");

            if (CarColorComboBox.SelectedItem == null)
                errors.AppendLine("Выберите цвет");

            if (EngineTypeComboBox.SelectedItem == null)
                errors.AppendLine("Выберите тип двигателя");

            if (TypeOfDriveComboBox.SelectedItem == null)
                errors.AppendLine("Выберите тип привода");

            if (DriverComboBox.SelectedItem == null)
                errors.AppendLine("Выберите водителя");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var context = GIBDDEntities.GetContext();
                var maxId = context.Cars.Any() ? context.Cars.Max(c => c.Id) : 0;
                var newId = maxId + 1;
                var newCar = new Cars
                {
                    Id = newId,
                    VIN = VinTextBox.Text,
                    Id_Manufacturer = (ManufacturerNameComboBox.SelectedItem as Manufacture)?.Id,
                    Id_Model = (ModelComboBox.SelectedItem as Model)?.Id,
                    Year = int.Parse(YearTextBox.Text),
                    Weight = int.Parse(WeightTextBox.Text),
                    Id_Color = (CarColorComboBox.SelectedItem as CarColors)?.ColorNum,
                    Id_EngineType = (EngineTypeComboBox.SelectedItem as EngineTypes)?.Id,
                    Id_TypeOfDrive = (TypeOfDriveComboBox.SelectedItem as TypeOfDrive)?.Id,
                    Id_Driver = (DriverComboBox.SelectedItem as Drivers)?.Id,
                };
                context.Cars.Add(newCar);
                context.SaveChanges();
                MessageBox.Show("Машина успешно добавлена!");
                var carWindow = new CarsWindow();
                carWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var carWindow = new CarsWindow();
            carWindow.Show();
            this.Close();
        }
    }
}