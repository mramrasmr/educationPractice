﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StringBuilder errors = new StringBuilder();

                if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
                    errors.AppendLine("Email не может быть пустым");

                if (string.IsNullOrWhiteSpace(PhoneTextBox.Text))
                    errors.AppendLine("Телефон не может быть пустым");

                if (!string.IsNullOrWhiteSpace(EmailTextBox.Text) && !Regex.IsMatch(EmailTextBox.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                    errors.AppendLine("Некорректный формат email");

                if (!string.IsNullOrWhiteSpace(PhoneTextBox.Text) && !Regex.IsMatch(PhoneTextBox.Text, @"^\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}$"))
                    errors.AppendLine("Телефон должен быть в формате +7 (XXX) XXX-XX-XX");

                if (errors.Length > 0)
                {
                    MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string email = EmailTextBox.Text;
                string phone = PhoneTextBox.Text;

                var context = GIBDDEntities.GetContext();

                var driver = context.Drivers.FirstOrDefault(d => d.Email == email && d.Phone == phone);

                if (driver != null)
                {
                    var mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Не удалось войти в систему");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }
    }
}