﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для CarEditWindow.xaml
    /// </summary>
    public partial class CarEditWindow : Window
    {
        private Cars _currentCar = new Cars();
        public CarEditWindow(Cars selectedCar)
        {
            InitializeComponent();
            try
            {
                ManufacturerNameComboBox.ItemsSource = GIBDDEntities.GetContext().Manufacture.ToList();
                ModelComboBox.ItemsSource = GIBDDEntities.GetContext().Model.ToList();
                CarColorComboBox.ItemsSource = GIBDDEntities.GetContext().CarColors.ToList();
                EngineTypeComboBox.ItemsSource = GIBDDEntities.GetContext().EngineTypes.ToList();
                TypeOfDriveComboBox.ItemsSource = GIBDDEntities.GetContext().TypeOfDrive.ToList();
                DriverComboBox.ItemsSource = GIBDDEntities.GetContext().Drivers.ToList();
                if (selectedCar == null)
                {
                    return;
                }
                _currentCar = selectedCar;
                DataContext = _currentCar;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentCar.VIN))
                errors.AppendLine("VIN не может быть пустым");
            else if (_currentCar.VIN.Length != 17)
                errors.AppendLine("VIN должен содержать 17 символов");

            if (_currentCar.Id_Manufacturer == null)
                errors.AppendLine("Выберите производителя");

            if (_currentCar.Id_Model == null)
                errors.AppendLine("Выберите модель");

            if (_currentCar.Year == null || _currentCar.Year < 1886 || _currentCar.Year > DateTime.Now.Year + 1)
                errors.AppendLine($"Год должен быть в диапазоне 1886 - {DateTime.Now.Year + 1}");

            if (_currentCar.Weight <= 0)
                errors.AppendLine("Вес должен быть больше 0");

            if (_currentCar.Id_Color == null)
                errors.AppendLine("Выберите цвет");

            if (_currentCar.Id_EngineType == null)
                errors.AppendLine("Выберите тип двигателя");

            if (_currentCar.Id_TypeOfDrive == null)
                errors.AppendLine("Выберите тип привода");

            if (_currentCar.Id_Driver == null)
                errors.AppendLine("Выберите водителя");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                GIBDDEntities.GetContext().SaveChanges();
                MessageBox.Show("Ура! Изменилось!");
                var carWindow = new CarsWindow();
                carWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var carWindow = new CarsWindow();
            carWindow.Show();
            this.Close();
        }
    }
}