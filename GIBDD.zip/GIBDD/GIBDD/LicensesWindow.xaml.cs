﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для LicensesWindow.xaml
    /// </summary>
    public partial class LicensesWindow : Window
    {
        private Licenses licenses = new Licenses();
        public LicensesWindow()
        {
            InitializeComponent();
            try
            {
                DataContext = licenses;
                WU.ItemsSource = GIBDDEntities.GetContext().Licenses.ToList();
                WU.ItemsSource =    GIBDDEntities.GetContext().Licenses.OrderBy(x => x.Id).ToList();
                SetLicenseColors();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void HistoryButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = (Licenses)WU.SelectedItem;
                if (item == null)
                {
                    MessageBox.Show("Пожалуйста, выберите лицензию для просмотра истории статусов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                new StatusHistory(item).Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void HistoryEditButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = (Licenses)WU.SelectedItem;
                if (item == null)
                {
                    MessageBox.Show("Пожалуйста, выберите лицензию для изменения статуса.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                new StatusHistoryEditWindow(item).Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var lincensesAddWindow = new LicensesAddWindow();
            lincensesAddWindow.Show();
            this.Close();
        }
        private void SetLicenseColors()
        {
            var context = GIBDDEntities.GetContext();
            var licenses = context.Licenses.OrderBy(x => x.Id).ToList();
            foreach (var license in licenses)
            {
                var statuses = license.LicensesStatus.Select(s => s.StatusName.ToLower()).ToList();

                if (statuses.Contains("приостановлен") || statuses.Contains("изъят"))
                    license.IndicatorColor = "Red";
                else if (statuses.Contains("актиен"))
                    license.IndicatorColor = "Green";
                else if (statuses.Contains("утратил силу"))
                    license.IndicatorColor = "Gray";
                else
                    license.IndicatorColor = "Transparent";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}