﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для DriverWindow.xaml
    /// </summary>
    public partial class DriverWindow : Window
    {
        private Drivers drivers = new Drivers();
        public DriverWindow()
        {
            InitializeComponent();
            try
            {
                DataContext = drivers;
                DriverDataGrid.ItemsSource = GIBDDEntities.GetContext().Drivers.ToList();
                DriverDataGrid.ItemsSource = GIBDDEntities.GetContext().Drivers.OrderBy(x => x.Id).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var driverWindow = new DriverAddWindow();
            driverWindow.Show();
            this.Close();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = (Drivers)DriverDataGrid.SelectedItem;
                if (item == null)
                {
                    MessageBox.Show("Пожалуйста, выберите водителя для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                new DriverEditWindow(item).Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var driverRemoving = DriverDataGrid.SelectedItems.Cast<Drivers>().ToList();
            if (driverRemoving.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите водителя(ей) для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (MessageBox.Show($"Подтвердить удаление?", "!",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) !=
                    MessageBoxResult.Yes) return;
                GIBDDEntities.GetContext().Drivers.RemoveRange(driverRemoving);
                GIBDDEntities.GetContext().SaveChanges();
                DriverDataGrid.ItemsSource = GIBDDEntities.GetContext().Drivers.ToList();
                DriverDataGrid.ItemsSource = GIBDDEntities.GetContext().Drivers.OrderBy(x => x.Id).ToList();
            }
            catch
            {
                MessageBox.Show("Нельзя удалить запись связанную с другой таблицей");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}