﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для DriverEditWindow.xaml
    /// </summary>
    public partial class DriverEditWindow : Window
    {
        private Drivers _currentDriver = new Drivers();
        public DriverEditWindow(Drivers selectedDriver)
        {
            InitializeComponent();
            try
            {
                if (selectedDriver == null)
                {
                    return;
                }
                _currentDriver = selectedDriver;
                DataContext = _currentDriver;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentDriver.Name))
                errors.AppendLine("Имя не может быть пустым");

            if (string.IsNullOrWhiteSpace(_currentDriver.LastName))
                errors.AppendLine("Фамилия не может быть пустой");

            if (string.IsNullOrWhiteSpace(_currentDriver.MiddleName))
                errors.AppendLine("Отчество не может быть пустым");

            if (string.IsNullOrWhiteSpace(_currentDriver.PassportSerial))
                errors.AppendLine("Серия паспорта не может быть пустой");
            else if (_currentDriver.PassportSerial.Length != 4 || !int.TryParse(_currentDriver.PassportSerial, out _))
                errors.AppendLine("Серия паспорта должна содержать 4 цифры");

            if (string.IsNullOrWhiteSpace(_currentDriver.PassportNumber))
                errors.AppendLine("Номер паспорта не может быть пустым");
            else if (_currentDriver.PassportNumber.Length != 6 || !int.TryParse(_currentDriver.PassportNumber, out _))
                errors.AppendLine("Номер паспорта должен содержать 6 цифр");

            if (!string.IsNullOrWhiteSpace(_currentDriver.Postcode) && (_currentDriver.Postcode.Length != 6 || !int.TryParse(_currentDriver.Postcode, out _)))
                errors.AppendLine("Индекс должен содержать 6 цифр или быть пустым");

            if (_currentDriver.Id_Address == null)
                errors.AppendLine("Адрес регистрации не может быть пустым");

            if (_currentDriver.Id_AddressLife == null)
                errors.AppendLine("Адрес проживания не может быть пустым");

            if (_currentDriver.Id_Company == null)
                errors.AppendLine("Компания не может быть пустой");

            if (_currentDriver.Id_JobName == null)
                errors.AppendLine("Должность не может быть пустой");

            if (!string.IsNullOrWhiteSpace(_currentDriver.Phone) && !Regex.IsMatch(_currentDriver.Phone, @"^\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}$"))
                errors.AppendLine("Телефон должен быть в формате +7 (XXX) XXX-XX-XX");

            if (!string.IsNullOrWhiteSpace(_currentDriver.Email) && !Regex.IsMatch(_currentDriver.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                errors.AppendLine("Некорректный формат email");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                GIBDDEntities.GetContext().SaveChanges();
                MessageBox.Show("Ура! Изменилось!");
                var driverWindow = new DriverWindow();
                driverWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var driverWindow = new DriverWindow();
            driverWindow.Show();
            this.Close();
        }
    }
}