﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для DriverAddWindow.xaml
    /// </summary>
    public partial class DriverAddWindow : Window
    {
        public DriverAddWindow()
        {
            InitializeComponent();
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StringBuilder errors = new StringBuilder();

                if (string.IsNullOrWhiteSpace(NameTextBox.Text))
                    errors.AppendLine("Имя не может быть пустым");

                if (string.IsNullOrWhiteSpace(LastNameTextBox.Text))
                    errors.AppendLine("Фамилия не может быть пустой");

                if (string.IsNullOrWhiteSpace(MiddleNameTextBox.Text))
                    errors.AppendLine("Отчество не может быть пустым");

                if (string.IsNullOrWhiteSpace(AdressTextBox.Text))
                    errors.AppendLine("Адрес регистрации не может быть пустым");

                if (string.IsNullOrWhiteSpace(AdressLiveTextBox.Text))
                    errors.AppendLine("Адрес проживания не может быть пустым");

                if (string.IsNullOrWhiteSpace(CompanyTextBox.Text))
                    errors.AppendLine("Название компании не может быть пустым");

                if (string.IsNullOrWhiteSpace(JobNameTextBox.Text))
                    errors.AppendLine("Должность не может быть пустой");

                if (string.IsNullOrWhiteSpace(PassportSerialTextBox.Text))
                    errors.AppendLine("Серия паспорта не может быть пустой");
                else if (PassportSerialTextBox.Text.Length != 4 || !int.TryParse(PassportSerialTextBox.Text, out _))
                    errors.AppendLine("Серия паспорта должна содержать 4 цифры");

                if (string.IsNullOrWhiteSpace(PassportNumberTextBox.Text))
                    errors.AppendLine("Номер паспорта не может быть пустым");
                else if (PassportNumberTextBox.Text.Length != 6 || !int.TryParse(PassportNumberTextBox.Text, out _))
                    errors.AppendLine("Номер паспорта должен содержать 6 цифр");

                if (!string.IsNullOrWhiteSpace(PostcodeTextBox.Text) && (PostcodeTextBox.Text.Length != 6 || !int.TryParse(PostcodeTextBox.Text, out _)))
                    errors.AppendLine("Индекс должен содержать 6 цифр или быть пустым");

                if (!string.IsNullOrWhiteSpace(PhoneTextBox.Text) && !Regex.IsMatch(PhoneTextBox.Text, @"^\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}$"))
                    errors.AppendLine("Телефон должен быть в формате +7 (XXX) XXX-XX-XX");

                if (!string.IsNullOrWhiteSpace(MailTextBox.Text) && !Regex.IsMatch(MailTextBox.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                    errors.AppendLine("Некорректный формат email");

                if (errors.Length > 0)
                {
                    MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var context =   GIBDDEntities.GetContext();

                var maxId = context.Drivers.Any() ? context.Drivers.Max(l => l.Id) : 0;
                var newId = maxId + 1;

                var maxIdAdress = context.Address.Any() ? context.Address.Max(l => l.Id) : 0;
                var maxIdCompany = context.Company.Any() ? context.Company.Max(l => l.Id) : 0;
                var maxIdJobName = context.JobName.Any() ? context.JobName.Max(l => l.Id) : 0;

                Address newAdress, newliveAdress;

                if (AdressLiveTextBox.Text == AdressTextBox.Text)
                {

                    var newIdAdress = maxIdAdress + 1;
                    newAdress = new Address { Id = newIdAdress, Address1 = AdressTextBox.Text };
                    newliveAdress = newAdress;

                    context.Address.Add(newAdress);
                    context.SaveChanges();
                }
                else
                {

                    var newIdAdress = maxIdAdress + 1;
                    var newLiveAdressId = maxIdAdress + 2;
                    newAdress = new Address { Id = newIdAdress, Address1 = AdressTextBox.Text };
                    newliveAdress = new Address { Id = newLiveAdressId, Address1 = AdressLiveTextBox.Text };

                    context.Address.Add(newAdress);
                    context.Address.Add(newliveAdress);
                    context.SaveChanges();
                }


                maxIdCompany = context.Company.Any() ? context.Company.Max(l => l.Id) : 0;
                maxIdJobName = context.JobName.Any() ? context.JobName.Max(l => l.Id) : 0;

                var newIdCompany = maxIdCompany + 1;
                var newIdJobName = maxIdJobName + 1;

                var newCompany = new Company { Id = newIdCompany, CompanyName = CompanyTextBox.Text };
                var newJobName = new JobName { Id = newIdJobName, JobName1 = JobNameTextBox.Text };

                context.Company.Add(newCompany);
                context.JobName.Add(newJobName);
                context.SaveChanges();

                var newdriver = new Drivers
                {
                    Id = newId,
                    Name = NameTextBox.Text,
                    LastName = LastNameTextBox.Text,
                    MiddleName = MiddleNameTextBox.Text,
                    PassportSerial = PassportSerialTextBox.Text,
                    PassportNumber = PassportNumberTextBox.Text,
                    Postcode = PostcodeTextBox.Text,
                    Id_Address = newAdress.Id,
                    Id_AddressLife = newliveAdress.Id,
                    Id_Company = newCompany.Id,
                    Id_JobName = newJobName.Id,
                    Phone = PhoneTextBox.Text,
                    Email = MailTextBox.Text,
                    Photo = PhotoTextBox.Text,
                    Description = DescriptionTextBox.Text
                };

                context.Drivers.Add(newdriver);
                context.SaveChanges();

                MessageBox.Show("Водитель добавлен");
                var driverWindow = new DriverWindow();
                driverWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }


        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var driverWindow = new DriverWindow();
            driverWindow.Show();
            this.Close();
        }
    }
}