﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для CarsWindow.xaml
    /// </summary>
    public partial class CarsWindow : Window
    {
        private Cars cars = new Cars();
        public CarsWindow()
        {
            InitializeComponent();
            try
            {
                DataContext = cars;
                CarsDataGrid.ItemsSource = GIBDDEntities.GetContext().Cars.ToList();
                CarsDataGrid.ItemsSource = GIBDDEntities.GetContext().Cars.OrderBy(x => x.Id).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var carsAddWindow = new CarsAddWindow();
            carsAddWindow.Show();
            this.Close();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = (Cars)CarsDataGrid.SelectedItem;
                if (item == null)
                {
                    MessageBox.Show("Пожалуйста, выберите автомобиль для редактирования.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                new CarEditWindow(item).Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var carRemoving = CarsDataGrid.SelectedItems.Cast<Cars>().ToList();
            if (carRemoving.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите автомобиль(и) для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (MessageBox.Show($"Подтвердить удаление?", "!",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) !=
                    MessageBoxResult.Yes) return;
                GIBDDEntities.GetContext().Cars.RemoveRange(carRemoving);
                GIBDDEntities.GetContext().SaveChanges();
                CarsDataGrid.ItemsSource = GIBDDEntities.GetContext().Cars.ToList();
                CarsDataGrid.ItemsSource = GIBDDEntities.GetContext().Cars.OrderBy(x => x.Id).ToList();
            }
            catch
            {
                MessageBox.Show("Нельзя удалить запись связанную с другой таблицей");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}