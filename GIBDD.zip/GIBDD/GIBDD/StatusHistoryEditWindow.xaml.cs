﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для StatusHistoryEditWindow.xaml
    /// </summary>
    public partial class StatusHistoryEditWindow : Window
    {
        public StatusHistoryEditWindow(Licenses selectedlicenses)
        {
            InitializeComponent();
            try
            {
                var licence = selectedlicenses;
                IdLincesTextBox.Text = licence.Id.ToString();
                LicensesStatusCombobox.ItemsSource = GIBDDEntities.GetContext().LicensesStatus.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedStatus = (LicensesStatus)LicensesStatusCombobox.SelectedItem;
                int lincenseId = int.Parse(IdLincesTextBox.Text);
                var context = GIBDDEntities.GetContext();
                var license = context.Licenses.Find(lincenseId);
                license.LicensesStatus.Add(selectedStatus);
                context.SaveChanges();
                MessageBox.Show("Запись добавлена");
                var licensesWindow = new LicensesWindow();
                licensesWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var licensesWindow = new LicensesWindow();
            licensesWindow.Show();
            this.Close();
        }
    }
}
