﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для LicensesAddWindow.xaml
    /// </summary>
    public partial class LicensesAddWindow : Window
    {
        public LicensesAddWindow()
        {
            InitializeComponent();
            try
            {
                LicensesStatusCombobox.ItemsSource = GIBDDEntities.GetContext().LicensesStatus.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(DateLincesTextBox.Text))
                errors.AppendLine("Дата выдачи не может быть пустой");

            if (string.IsNullOrWhiteSpace(ExpireDateLincesTextBox.Text))
                errors.AppendLine("Дата окончания не может быть пустой");

            if (string.IsNullOrWhiteSpace(seriesLincesTextBox.Text))
                errors.AppendLine("Серия лицензии не может быть пустой");

            if (string.IsNullOrWhiteSpace(NumberLincesTextBox.Text))
                errors.AppendLine("Номер лицензии не может быть пустым");

            if (string.IsNullOrWhiteSpace(IdDriverLincesTextBox.Text))
                errors.AppendLine("ID водителя не может быть пустым");
            else if (!int.TryParse(IdDriverLincesTextBox.Text, out int driverId) || driverId <= 0)
                errors.AppendLine("ID водителя должно быть положительным числом");

            if (LicensesStatusCombobox.SelectedItem == null)
                errors.AppendLine("Выберите статус лицензии");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DateTime licenceDate = DateTime.Parse(DateLincesTextBox.Text);
                DateTime expireDate = DateTime.Parse(ExpireDateLincesTextBox.Text);

                if (expireDate <= licenceDate)
                    errors.AppendLine("Дата окончания должна быть позже даты выдачи");

                if (errors.Length > 0)
                {
                    MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var context = GIBDDEntities.GetContext();
                var maxId = context.Licenses.Any() ? context.Licenses.Max(l => l.Id) : 0;
                var newId = maxId + 1;
                var newLicense = new Licenses
                {
                    Id = newId,
                    LicenceDate = licenceDate,
                    ExpireDate = expireDate,
                    LicenceSeries = seriesLincesTextBox.Text,
                    LicenceNumber = NumberLincesTextBox.Text,
                    Id_Driver = int.Parse(IdDriverLincesTextBox.Text),
                };
                context.Licenses.Add(newLicense);
                var selectedStatus = (LicensesStatus)LicensesStatusCombobox.SelectedItem;
                context.SaveChanges();
                int lincenseId = newId;
                var license = context.Licenses.Find(lincenseId);
                license.LicensesStatus.Add(selectedStatus);
                context.SaveChanges();
                MessageBox.Show("Запись добавлена");
                var licensesWindow = new LicensesWindow();
                licensesWindow.Show();
                this.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Некорректный формат даты. Используйте формат, например, dd.MM.yyyy", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            var licensesWindow = new LicensesWindow();
            licensesWindow.Show();
            this.Close();
        }
    }
}