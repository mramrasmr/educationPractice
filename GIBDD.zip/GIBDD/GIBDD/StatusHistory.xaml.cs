﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIBDD
{
    /// <summary>
    /// Логика взаимодействия для StatusHistory.xaml
    /// </summary>
    public partial class StatusHistory : Window
    {

        public StatusHistory(Licenses selectedlicenses)
        {
            InitializeComponent();
            try
            {
                var context = GIBDDEntities.GetContext();
                var query = from licenses in context.Licenses
                            from status in licenses.LicensesStatus
                            where licenses.Id == selectedlicenses.Id
                            select new { licenceSeries = licenses.LicenceSeries, licenceNumber = licenses.LicenceNumber, statusName = status.StatusName };
                datalls.ItemsSource = query.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            var licensesWindow = new LicensesWindow();
            licensesWindow.Show();
            this.Close();
        }
    }
}
